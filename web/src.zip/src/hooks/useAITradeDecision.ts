import { AITradeDecision, AIRating, RiskLevel, TimeHorizon, DecisionStatus } from '../types/domain';

export const normalizeAITradeDecision = (stock: any): AITradeDecision => {
  if (!stock) return {
    rating: 'HOLD',
    conviction: 0,
    riskLevel: 'MODERATE',
    timeframe: 'SWING',
    status: 'UNAVAILABLE'
  };

  const analysis = stock.analysis || {};
  const structured = stock.structured_consensus || {};

  // 1. Normalize Rating
  const rawRating = (structured.rating || analysis.consensus || 'HOLD').toUpperCase();
  let rating: AIRating = 'HOLD';
  if (rawRating.includes('STRONG BUY')) rating = 'STRONG BUY';
  else if (rawRating.includes('STRONG SELL')) rating = 'STRONG SELL';
  else if (rawRating.includes('BUY')) rating = 'BUY';
  else if (rawRating.includes('SELL')) rating = 'SELL';

  // 2. Normalize Conviction (0-100)
  const conviction = Math.round(
    (structured.conviction !== undefined && structured.conviction !== null)
    ? structured.conviction : (stock.ai_investment_score || 0)
  );

  // 3. Normalize Risk Level
  let riskLevel: RiskLevel = 'MODERATE';
  const rawRisk = (structured.riskLevel || '').toUpperCase();
  if (rawRisk === 'LOW') riskLevel = 'LOW';
  else if (rawRisk === 'HIGH') riskLevel = 'HIGH';
  else {
    const beta = stock.beta || 1.0;
    if (beta > 1.2) riskLevel = 'HIGH';
    else if (beta < 0.8) riskLevel = 'LOW';
  }

  // 4. Normalize Timeframe
  const rawTf = (structured.timeframe || stock.timeframe || 'SWING').toUpperCase().replace('_', ' ');
  let timeframe: TimeHorizon = 'SWING';
  if (rawTf.includes('INTRADAY')) timeframe = 'INTRADAY';
  else if (rawTf.includes('SHORT')) timeframe = 'SHORT TERM';
  else if (rawTf.includes('POSITION') || rawTf.includes('MID')) timeframe = 'POSITION';
  else if (rawTf.includes('LONG')) timeframe = 'LONG TERM';

  // 5. Decision Status
  let status: DecisionStatus = 'ACTIVE';
  if (!stock.analysis) status = 'UNAVAILABLE';
  else if (structured.status) status = structured.status as DecisionStatus;

  // 6. Entry Logic
  const parseNum = (val: any) => {
    if (val === null || val === undefined || val === 'Unknown' || val === 'N/A') return undefined;
    const num = Number(val);
    return isNaN(num) ? undefined : num;
  };

  const entry = parseNum(structured.entry) || stock.last_price || 0;
  let target = parseNum(structured.target);
  let stopLoss = parseNum(structured.stop_loss);

  // 6.1 Heuristic Fallback for Missing Targets/Stops (Vision 2.2 Alignment)
  // Ensure we always have a numeric target/stop for active BUY/SELL signals
  // Also guard against NaN specifically
  if (rating.includes('BUY') && entry > 0) {
    if (!target || isNaN(target)) {
       const multiplier = rating.includes('STRONG') ? 1.15 : 1.08;
       target = entry * multiplier;
    }
    if (!stopLoss || isNaN(stopLoss)) {
       stopLoss = entry * 0.96;
    }
  } else if (rating.includes('SELL') && entry > 0) {
    if (!target || isNaN(target)) {
       const multiplier = rating.includes('STRONG') ? 0.85 : 0.92;
       target = entry * multiplier;
    }
    if (!stopLoss || isNaN(stopLoss)) {
       stopLoss = entry * 1.04;
    }
  }

  // Ensure 0 is used instead of NaN for display if no logic could determine a price
  target = target && !isNaN(target) ? target : (entry * 1.05);
  stopLoss = stopLoss && !isNaN(stopLoss) ? stopLoss : (entry * 0.97);

  // 7. Drivers (Explainability)
  let drivers = Array.isArray(structured.drivers) ? structured.drivers : [];
  if (drivers.length === 0 && Array.isArray(analysis.recommendations)) {
     drivers = analysis.recommendations[0]?.reasons?.slice(0, 3) || [];
  }
  drivers = (drivers as any[]).filter(d => typeof d === 'string' && !d.includes('{'));

  // 8. Robust Thesis/Reasoning
  let thesis = structured.thesis || analysis.consensus || 'Analyzing session dynamics...';

  // Prevent raw JSON or Code from leaking into UI
  const codeMarkers = ['{', '```', 'import ', 'def ', 'return ', 'json.'];
  const isLikelyCode = codeMarkers.some(m => thesis.includes(m));

  if (isLikelyCode) {
    if (structured.thesis && !structured.thesis.includes('{')) {
      thesis = structured.thesis;
    } else {
      // Try to extract thesis from raw string if parsing failed
      const match = thesis.match(/["']thesis["']:\s*["'](.*?)["']/);
      thesis = (match && match[1]) ? match[1] : 'Synthesis in progress...';
    }
  }

  // Final trim to remove any remaining artifacts
  if (thesis.length > 500) thesis = thesis.substring(0, 497) + '...';

  return {
    rating,
    conviction,
    riskLevel,
    timeframe,
    status,
    entry,
    target,
    targetRange: structured.target_range,
    stopLoss,
    stopRange: structured.stop_range,
    riskReward: structured.risk_reward || '1:2.0',
    primaryCatalyst: structured.key_catalysts?.[0] || (analysis.recommendations?.[0] as any)?.reasons?.[0],
    keyRisks: structured.key_risks || (analysis.recommendations?.[0] as any)?.risks,
    thesis,
    invalidation: structured.invalidation_point,
    generatedAt: stock.timestamp,
    validatedAt: stock.validated_at,
    triggeredAt: stock.triggered_at,
    triggerPrice: stock.trigger_price,
    triggerCondition: stock.trigger_condition,
    outcomeDate: stock.outcome_date,
    profitPct: stock.profit_pct,
    mfe: stock.mfe,
    mae: stock.mae,
    updatedAt: stock.updated_at,
    modelVersion: structured.modelVersion || 'TradeMind Core v2.2',
    drivers,
    events: stock.events || []
  };
};

export const useAITradeDecision = (stock: any): AITradeDecision => {
  return normalizeAITradeDecision(stock);
};
